using HotelApp.Models;
using static HotelApp.Models.MenuClass;

namespace HotelApp
{
    public class Program
    {
        public static void Main(string[] args)
        {
            const string policyName = "myPolicy";
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddAuthorization();
            builder.Services.AddTransient<IMenuComponent,MenuComponent>();

            var app = builder.Build();

            // Configure the HTTP request pipeline.

            app.UseAuthorization();

            app.MapGet("/menu", (IMenuComponent com) =>
            {
                return com.GetMenu();
            });
            app.MapGet("/menu/{id}", (int id, IMenuComponent com) =>
            {
                return com.GetMenuItem(id);
            });
            app.MapPost("/menu", (MenuClass item, IMenuComponent com) =>
            {
                com.AddItem(item);
                return "Item Added Successfully";
            });

            app.MapDelete("/menu/{id}", (int id, IMenuComponent com) =>
            {
                com.RemoveItem(id);

            });
            app.MapPut("/menu/{id}", (MenuClass item, IMenuComponent com) =>
            {
                com.UpdateItem(item);
                return "Item Updated Successfully";
            });

            app.Run();
        }
    }
}