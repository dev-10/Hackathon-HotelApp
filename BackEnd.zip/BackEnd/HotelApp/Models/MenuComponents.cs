﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Numerics;

namespace HotelApp.Models
{
    [Table("MenuTable")]
    public class MenuClass
    {
        [Key]
        public int Id { get; set; }

        public string Item_Name { get; set; } = string.Empty;

        public string Item_Image { get; set; } = string.Empty;

        public int Item_Price { get; set; }


        public class MenuDbContext : DbContext
        {
            public DbSet<MenuClass> Menu { get; set; }

            protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
            {
                const string strConnection = @"Data Source=W-674PY03-1;Initial Catalog=DevDb;Persist Security Info=True;User ID=sa;Password=Password@12345; TrustServerCertificate=True";
                base.OnConfiguring(optionsBuilder);
                optionsBuilder.UseSqlServer(strConnection);
            }

        }

        public interface IMenuComponent
        {
            List<MenuClass> GetMenu();
            MenuClass GetMenuItem(int id);

            void AddItem(MenuClass item);

            void UpdateItem(MenuClass item);
            void RemoveItem(int id);

        }

        public class MenuComponent : IMenuComponent
        {
            public void AddItem(MenuClass item)
            {
                var context = new MenuDbContext();
                context.Menu.Add(item);
                context.SaveChanges();
            }

            public List<MenuClass> GetMenu()
            {
               var context = new MenuDbContext();
               return context.Menu.ToList();
            }

            public MenuClass GetMenuItem(int id)
            {
                var context = new MenuDbContext();
                var rec = context.Menu.FirstOrDefault(m => m.Id == id);
                if (rec != null)
                {
                    return rec;
                }
                else
                {
                    throw new Exception("Menu Item not found");
                }
            }

            public void RemoveItem(int id)
            {
                var context = new MenuDbContext();
                var rec = context.Menu.FirstOrDefault((m) => m.Id == id);
                if (rec != null)
                {
                    context.Menu.Remove(rec);
                    context.SaveChanges();
                }
                else
                {
                    throw new Exception("Item not found to delete");
                }
            }

            public void UpdateItem(MenuClass item)
            {
                var context = new MenuDbContext();
                var data = context.Menu.FirstOrDefault(m => m.Id ==item.Id);
                if (data != null)
                {
                    data.Item_Name = item.Item_Name;
                    data.Item_Image = item.Item_Image;
                    data.Item_Price = item.Item_Price;
                }
                context.SaveChanges();

            }
        }
    }

}